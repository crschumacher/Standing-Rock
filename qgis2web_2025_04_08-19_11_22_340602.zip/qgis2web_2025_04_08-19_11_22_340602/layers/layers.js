var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_StandingRockDistricts_1 = new ol.format.GeoJSON();
var features_StandingRockDistricts_1 = format_StandingRockDistricts_1.readFeatures(json_StandingRockDistricts_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_StandingRockDistricts_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_StandingRockDistricts_1.addFeatures(features_StandingRockDistricts_1);
var lyr_StandingRockDistricts_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_StandingRockDistricts_1, 
                style: style_StandingRockDistricts_1,
                popuplayertitle: 'Standing Rock Districts',
                interactive: true,
                title: '<img src="styles/legend/StandingRockDistricts_1.png" /> Standing Rock Districts'
            });
var format_1011_HUC6_Clipped_2 = new ol.format.GeoJSON();
var features_1011_HUC6_Clipped_2 = format_1011_HUC6_Clipped_2.readFeatures(json_1011_HUC6_Clipped_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_1011_HUC6_Clipped_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_1011_HUC6_Clipped_2.addFeatures(features_1011_HUC6_Clipped_2);
var lyr_1011_HUC6_Clipped_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_1011_HUC6_Clipped_2, 
                style: style_1011_HUC6_Clipped_2,
                popuplayertitle: '1011_HUC6_Clipped',
                interactive: true,
    title: '1011_HUC6_Clipped<br />\
    <img src="styles/legend/1011_HUC6_Clipped_2_0.png" /> Cannonball-Heart-Knife<br />\
    <img src="styles/legend/1011_HUC6_Clipped_2_1.png" /> Grand-Moreau<br />\
    <img src="styles/legend/1011_HUC6_Clipped_2_2.png" /> Lake Oahe<br />' });
var format_ProjectFP_3 = new ol.format.GeoJSON();
var features_ProjectFP_3 = format_ProjectFP_3.readFeatures(json_ProjectFP_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ProjectFP_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ProjectFP_3.addFeatures(features_ProjectFP_3);
var lyr_ProjectFP_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ProjectFP_3, 
                style: style_ProjectFP_3,
                popuplayertitle: 'Project FP',
                interactive: true,
                title: '<img src="styles/legend/ProjectFP_3.png" /> Project FP'
            });
var format_LeafOnTheHillCreek_4 = new ol.format.GeoJSON();
var features_LeafOnTheHillCreek_4 = format_LeafOnTheHillCreek_4.readFeatures(json_LeafOnTheHillCreek_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_LeafOnTheHillCreek_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_LeafOnTheHillCreek_4.addFeatures(features_LeafOnTheHillCreek_4);
var lyr_LeafOnTheHillCreek_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_LeafOnTheHillCreek_4, 
                style: style_LeafOnTheHillCreek_4,
                popuplayertitle: 'Leaf On The Hill Creek',
                interactive: true,
                title: '<img src="styles/legend/LeafOnTheHillCreek_4.png" /> Leaf On The Hill Creek'
            });
var format_CannonballRivertributaries_5 = new ol.format.GeoJSON();
var features_CannonballRivertributaries_5 = format_CannonballRivertributaries_5.readFeatures(json_CannonballRivertributaries_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CannonballRivertributaries_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CannonballRivertributaries_5.addFeatures(features_CannonballRivertributaries_5);
var lyr_CannonballRivertributaries_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_CannonballRivertributaries_5, 
                style: style_CannonballRivertributaries_5,
                popuplayertitle: 'Cannonball River tributaries',
                interactive: true,
                title: '<img src="styles/legend/CannonballRivertributaries_5.png" /> Cannonball River tributaries'
            });
var format_CannonballRiversr_nhd_area_6 = new ol.format.GeoJSON();
var features_CannonballRiversr_nhd_area_6 = format_CannonballRiversr_nhd_area_6.readFeatures(json_CannonballRiversr_nhd_area_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CannonballRiversr_nhd_area_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CannonballRiversr_nhd_area_6.addFeatures(features_CannonballRiversr_nhd_area_6);
var lyr_CannonballRiversr_nhd_area_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_CannonballRiversr_nhd_area_6, 
                style: style_CannonballRiversr_nhd_area_6,
                popuplayertitle: 'Cannonball River - sr_nhd_area',
                interactive: true,
                title: '<img src="styles/legend/CannonballRiversr_nhd_area_6.png" /> Cannonball River - sr_nhd_area'
            });
var format_CannonballRiversr_nhd_flowline_7 = new ol.format.GeoJSON();
var features_CannonballRiversr_nhd_flowline_7 = format_CannonballRiversr_nhd_flowline_7.readFeatures(json_CannonballRiversr_nhd_flowline_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_CannonballRiversr_nhd_flowline_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_CannonballRiversr_nhd_flowline_7.addFeatures(features_CannonballRiversr_nhd_flowline_7);
var lyr_CannonballRiversr_nhd_flowline_7 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_CannonballRiversr_nhd_flowline_7, 
                style: style_CannonballRiversr_nhd_flowline_7,
                popuplayertitle: 'Cannonball River — sr_nhd_flowline',
                interactive: true,
                title: '<img src="styles/legend/CannonballRiversr_nhd_flowline_7.png" /> Cannonball River — sr_nhd_flowline'
            });
var format_GrandRivertributaries_8 = new ol.format.GeoJSON();
var features_GrandRivertributaries_8 = format_GrandRivertributaries_8.readFeatures(json_GrandRivertributaries_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_GrandRivertributaries_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_GrandRivertributaries_8.addFeatures(features_GrandRivertributaries_8);
var lyr_GrandRivertributaries_8 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_GrandRivertributaries_8, 
                style: style_GrandRivertributaries_8,
                popuplayertitle: 'Grand River tributaries',
                interactive: true,
                title: '<img src="styles/legend/GrandRivertributaries_8.png" /> Grand River tributaries'
            });
var format_GrandRiversr_nhd_area_9 = new ol.format.GeoJSON();
var features_GrandRiversr_nhd_area_9 = format_GrandRiversr_nhd_area_9.readFeatures(json_GrandRiversr_nhd_area_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_GrandRiversr_nhd_area_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_GrandRiversr_nhd_area_9.addFeatures(features_GrandRiversr_nhd_area_9);
var lyr_GrandRiversr_nhd_area_9 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_GrandRiversr_nhd_area_9, 
                style: style_GrandRiversr_nhd_area_9,
                popuplayertitle: 'Grand River - sr_nhd_area',
                interactive: true,
                title: '<img src="styles/legend/GrandRiversr_nhd_area_9.png" /> Grand River - sr_nhd_area'
            });
var format_GrandRiversr_nhd_flowline_10 = new ol.format.GeoJSON();
var features_GrandRiversr_nhd_flowline_10 = format_GrandRiversr_nhd_flowline_10.readFeatures(json_GrandRiversr_nhd_flowline_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_GrandRiversr_nhd_flowline_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_GrandRiversr_nhd_flowline_10.addFeatures(features_GrandRiversr_nhd_flowline_10);
var lyr_GrandRiversr_nhd_flowline_10 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_GrandRiversr_nhd_flowline_10, 
                style: style_GrandRiversr_nhd_flowline_10,
                popuplayertitle: 'Grand River — sr_nhd_flowline',
                interactive: true,
                title: '<img src="styles/legend/GrandRiversr_nhd_flowline_10.png" /> Grand River — sr_nhd_flowline'
            });
var format_OakCreek_11 = new ol.format.GeoJSON();
var features_OakCreek_11 = format_OakCreek_11.readFeatures(json_OakCreek_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_OakCreek_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_OakCreek_11.addFeatures(features_OakCreek_11);
var lyr_OakCreek_11 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_OakCreek_11, 
                style: style_OakCreek_11,
                popuplayertitle: 'Oak Creek',
                interactive: true,
                title: '<img src="styles/legend/OakCreek_11.png" /> Oak Creek'
            });
var format_MissouriRivertributariesmerge_12 = new ol.format.GeoJSON();
var features_MissouriRivertributariesmerge_12 = format_MissouriRivertributariesmerge_12.readFeatures(json_MissouriRivertributariesmerge_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_MissouriRivertributariesmerge_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MissouriRivertributariesmerge_12.addFeatures(features_MissouriRivertributariesmerge_12);
var lyr_MissouriRivertributariesmerge_12 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_MissouriRivertributariesmerge_12, 
                style: style_MissouriRivertributariesmerge_12,
                popuplayertitle: 'Missouri River tributaries merge',
                interactive: true,
                title: '<img src="styles/legend/MissouriRivertributariesmerge_12.png" /> Missouri River tributaries merge'
            });
var format_MissouriRiversr_nhd_wb_13 = new ol.format.GeoJSON();
var features_MissouriRiversr_nhd_wb_13 = format_MissouriRiversr_nhd_wb_13.readFeatures(json_MissouriRiversr_nhd_wb_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_MissouriRiversr_nhd_wb_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MissouriRiversr_nhd_wb_13.addFeatures(features_MissouriRiversr_nhd_wb_13);
var lyr_MissouriRiversr_nhd_wb_13 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_MissouriRiversr_nhd_wb_13, 
                style: style_MissouriRiversr_nhd_wb_13,
                popuplayertitle: 'Missouri River - sr_nhd_wb',
                interactive: true,
                title: '<img src="styles/legend/MissouriRiversr_nhd_wb_13.png" /> Missouri River - sr_nhd_wb'
            });
var format_MissouriRiversr_nhd_area_14 = new ol.format.GeoJSON();
var features_MissouriRiversr_nhd_area_14 = format_MissouriRiversr_nhd_area_14.readFeatures(json_MissouriRiversr_nhd_area_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_MissouriRiversr_nhd_area_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MissouriRiversr_nhd_area_14.addFeatures(features_MissouriRiversr_nhd_area_14);
var lyr_MissouriRiversr_nhd_area_14 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_MissouriRiversr_nhd_area_14, 
                style: style_MissouriRiversr_nhd_area_14,
                popuplayertitle: 'Missouri River - sr_nhd_area',
                interactive: true,
                title: '<img src="styles/legend/MissouriRiversr_nhd_area_14.png" /> Missouri River - sr_nhd_area'
            });
var format_MissouriRiversr_nhd_flowline_15 = new ol.format.GeoJSON();
var features_MissouriRiversr_nhd_flowline_15 = format_MissouriRiversr_nhd_flowline_15.readFeatures(json_MissouriRiversr_nhd_flowline_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_MissouriRiversr_nhd_flowline_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MissouriRiversr_nhd_flowline_15.addFeatures(features_MissouriRiversr_nhd_flowline_15);
var lyr_MissouriRiversr_nhd_flowline_15 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_MissouriRiversr_nhd_flowline_15, 
                style: style_MissouriRiversr_nhd_flowline_15,
                popuplayertitle: 'Missouri River — sr_nhd_flowline',
                interactive: true,
                title: '<img src="styles/legend/MissouriRiversr_nhd_flowline_15.png" /> Missouri River — sr_nhd_flowline'
            });
var group_MissouriRiver = new ol.layer.Group({
                                layers: [lyr_OakCreek_11,lyr_MissouriRivertributariesmerge_12,lyr_MissouriRiversr_nhd_wb_13,lyr_MissouriRiversr_nhd_area_14,lyr_MissouriRiversr_nhd_flowline_15,],
                                fold: "open",
                                title: 'Missouri River'});
var group_GrandRiver = new ol.layer.Group({
                                layers: [lyr_GrandRivertributaries_8,lyr_GrandRiversr_nhd_area_9,lyr_GrandRiversr_nhd_flowline_10,],
                                fold: "open",
                                title: 'Grand River'});
var group_CannonballRiver = new ol.layer.Group({
                                layers: [lyr_LeafOnTheHillCreek_4,lyr_CannonballRivertributaries_5,lyr_CannonballRiversr_nhd_area_6,lyr_CannonballRiversr_nhd_flowline_7,],
                                fold: "open",
                                title: 'Cannonball River'});
var group_Boundaries = new ol.layer.Group({
                                layers: [lyr_ProjectFP_3,],
                                fold: "open",
                                title: 'Boundaries'});
var group_isolated = new ol.layer.Group({
                                layers: [lyr_StandingRockDistricts_1,lyr_1011_HUC6_Clipped_2,],
                                fold: "open",
                                title: 'isolated'});

lyr_OpenStreetMap_0.setVisible(true);lyr_StandingRockDistricts_1.setVisible(true);lyr_1011_HUC6_Clipped_2.setVisible(true);lyr_ProjectFP_3.setVisible(true);lyr_LeafOnTheHillCreek_4.setVisible(true);lyr_CannonballRivertributaries_5.setVisible(true);lyr_CannonballRiversr_nhd_area_6.setVisible(true);lyr_CannonballRiversr_nhd_flowline_7.setVisible(true);lyr_GrandRivertributaries_8.setVisible(true);lyr_GrandRiversr_nhd_area_9.setVisible(true);lyr_GrandRiversr_nhd_flowline_10.setVisible(true);lyr_OakCreek_11.setVisible(true);lyr_MissouriRivertributariesmerge_12.setVisible(true);lyr_MissouriRiversr_nhd_wb_13.setVisible(true);lyr_MissouriRiversr_nhd_area_14.setVisible(true);lyr_MissouriRiversr_nhd_flowline_15.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,group_isolated,group_Boundaries,group_CannonballRiver,group_GrandRiver,group_MissouriRiver];
lyr_StandingRockDistricts_1.set('fieldAliases', {'AIANNHCE': 'AIANNHCE', 'TRSUBCE': 'TRSUBCE', 'TRSUBNS': 'TRSUBNS', 'GEOID': 'GEOID', 'NAME': 'NAME', 'NAMELSAD': 'NAMELSAD', 'LSAD': 'LSAD', 'CLASSFP': 'CLASSFP', 'MTFCC': 'MTFCC', 'FUNCSTAT': 'FUNCSTAT', 'ALAND': 'ALAND', 'AWATER': 'AWATER', 'INTPTLAT': 'INTPTLAT', 'INTPTLON': 'INTPTLON', });
lyr_1011_HUC6_Clipped_2.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'TNMID': 'TNMID', 'MetaSource': 'MetaSource', 'SourceData': 'SourceData', 'SourceOrig': 'SourceOrig', 'SourceFeat': 'SourceFeat', 'LoadDate': 'LoadDate', 'AreaSqKm': 'AreaSqKm', 'AreaAcres': 'AreaAcres', 'GNIS_ID': 'GNIS_ID', 'Name': 'Name', 'States': 'States', 'HUC6': 'HUC6', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ProjectFP_3.set('fieldAliases', {'id': 'id', 'name': 'name', });
lyr_LeafOnTheHillCreek_4.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Shape_Leng': 'Shape_Leng', 'statecode': 'statecode', 'permanent_': 'permanent_', 'fdate': 'fdate', 'resolution': 'resolution', 'gnis_id': 'gnis_id', 'gnis_name': 'gnis_name', 'lengthkm': 'lengthkm', 'reachcode': 'reachcode', 'flowdir': 'flowdir', 'wbarea_per': 'wbarea_per', 'ftype': 'ftype', 'fcode': 'fcode', 'mainpath': 'mainpath', 'innetwork': 'innetwork', 'visibility': 'visibility', 'enabled': 'enabled', 'vpuid': 'vpuid', 'nhdplusid': 'nhdplusid', 'fmeasure': 'fmeasure', 'tmeasure': 'tmeasure', 'GlobalID': 'GlobalID', 'layer': 'layer', 'path': 'path', });
lyr_CannonballRivertributaries_5.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Shape_Leng': 'Shape_Leng', 'statecode': 'statecode', 'permanent_': 'permanent_', 'fdate': 'fdate', 'resolution': 'resolution', 'gnis_id': 'gnis_id', 'gnis_name': 'gnis_name', 'lengthkm': 'lengthkm', 'reachcode': 'reachcode', 'flowdir': 'flowdir', 'wbarea_per': 'wbarea_per', 'ftype': 'ftype', 'fcode': 'fcode', 'mainpath': 'mainpath', 'innetwork': 'innetwork', 'visibility': 'visibility', 'enabled': 'enabled', 'vpuid': 'vpuid', 'nhdplusid': 'nhdplusid', 'fmeasure': 'fmeasure', 'tmeasure': 'tmeasure', 'GlobalID': 'GlobalID', 'layer': 'layer', 'path': 'path', });
lyr_CannonballRiversr_nhd_area_6.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'LengthKM': 'LengthKM', 'ReachCode': 'ReachCode', 'FlowDir': 'FlowDir', 'WBArea_Per': 'WBArea_Per', 'FType': 'FType', 'FCode': 'FCode', 'MainPath': 'MainPath', 'InNetwork': 'InNetwork', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', 'Enabled': 'Enabled', 'fid_2': 'fid_2', 'OBJECTID_2': 'OBJECTID_2', 'Permanen_1': 'Permanen_1', 'FDate_2': 'FDate_2', 'Resoluti_1': 'Resoluti_1', 'GNIS_ID_2': 'GNIS_ID_2', 'GNIS_Name_': 'GNIS_Name_', 'AreaSqKm': 'AreaSqKm', 'Elevation': 'Elevation', 'FType_2': 'FType_2', 'FCode_2': 'FCode_2', 'Visibili_1': 'Visibili_1', 'Shape_Le_1': 'Shape_Le_1', 'Shape_Area': 'Shape_Area', 'NHDPlusID_': 'NHDPlusID_', 'VPUID_2': 'VPUID_2', });
lyr_CannonballRiversr_nhd_flowline_7.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'LengthKM': 'LengthKM', 'ReachCode': 'ReachCode', 'FlowDir': 'FlowDir', 'WBArea_Per': 'WBArea_Per', 'FType': 'FType', 'FCode': 'FCode', 'MainPath': 'MainPath', 'InNetwork': 'InNetwork', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', 'Enabled': 'Enabled', });
lyr_GrandRivertributaries_8.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Shape_Leng': 'Shape_Leng', 'statecode': 'statecode', 'permanent_': 'permanent_', 'fdate': 'fdate', 'resolution': 'resolution', 'gnis_id': 'gnis_id', 'gnis_name': 'gnis_name', 'lengthkm': 'lengthkm', 'reachcode': 'reachcode', 'flowdir': 'flowdir', 'wbarea_per': 'wbarea_per', 'ftype': 'ftype', 'fcode': 'fcode', 'mainpath': 'mainpath', 'innetwork': 'innetwork', 'visibility': 'visibility', 'enabled': 'enabled', 'vpuid': 'vpuid', 'nhdplusid': 'nhdplusid', 'fmeasure': 'fmeasure', 'tmeasure': 'tmeasure', 'GlobalID': 'GlobalID', 'layer': 'layer', 'path': 'path', });
lyr_GrandRiversr_nhd_area_9.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'AreaSqKm': 'AreaSqKm', 'Elevation': 'Elevation', 'FType': 'FType', 'FCode': 'FCode', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', });
lyr_GrandRiversr_nhd_flowline_10.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'LengthKM': 'LengthKM', 'ReachCode': 'ReachCode', 'FlowDir': 'FlowDir', 'WBArea_Per': 'WBArea_Per', 'FType': 'FType', 'FCode': 'FCode', 'MainPath': 'MainPath', 'InNetwork': 'InNetwork', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', 'Enabled': 'Enabled', });
lyr_OakCreek_11.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Shape_Leng': 'Shape_Leng', 'statecode': 'statecode', 'permanent_': 'permanent_', 'fdate': 'fdate', 'resolution': 'resolution', 'gnis_id': 'gnis_id', 'gnis_name': 'gnis_name', 'lengthkm': 'lengthkm', 'reachcode': 'reachcode', 'flowdir': 'flowdir', 'wbarea_per': 'wbarea_per', 'ftype': 'ftype', 'fcode': 'fcode', 'mainpath': 'mainpath', 'innetwork': 'innetwork', 'visibility': 'visibility', 'enabled': 'enabled', 'vpuid': 'vpuid', 'nhdplusid': 'nhdplusid', 'fmeasure': 'fmeasure', 'tmeasure': 'tmeasure', 'GlobalID': 'GlobalID', 'layer': 'layer', 'path': 'path', });
lyr_MissouriRivertributariesmerge_12.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Shape_Leng': 'Shape_Leng', 'statecode': 'statecode', 'permanent_': 'permanent_', 'fdate': 'fdate', 'resolution': 'resolution', 'gnis_id': 'gnis_id', 'gnis_name': 'gnis_name', 'lengthkm': 'lengthkm', 'reachcode': 'reachcode', 'flowdir': 'flowdir', 'wbarea_per': 'wbarea_per', 'ftype': 'ftype', 'fcode': 'fcode', 'mainpath': 'mainpath', 'innetwork': 'innetwork', 'visibility': 'visibility', 'enabled': 'enabled', 'vpuid': 'vpuid', 'nhdplusid': 'nhdplusid', 'fmeasure': 'fmeasure', 'tmeasure': 'tmeasure', 'GlobalID': 'GlobalID', 'layer': 'layer', 'path': 'path', });
lyr_MissouriRiversr_nhd_wb_13.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'AreaSqKm': 'AreaSqKm', 'Elevation': 'Elevation', 'ReachCode': 'ReachCode', 'FType': 'FType', 'FCode': 'FCode', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', });
lyr_MissouriRiversr_nhd_area_14.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'AreaSqKm': 'AreaSqKm', 'Elevation': 'Elevation', 'FType': 'FType', 'FCode': 'FCode', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', });
lyr_MissouriRiversr_nhd_flowline_15.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'Permanent_': 'Permanent_', 'FDate': 'FDate', 'Resolution': 'Resolution', 'GNIS_ID': 'GNIS_ID', 'GNIS_Name': 'GNIS_Name', 'LengthKM': 'LengthKM', 'ReachCode': 'ReachCode', 'FlowDir': 'FlowDir', 'WBArea_Per': 'WBArea_Per', 'FType': 'FType', 'FCode': 'FCode', 'MainPath': 'MainPath', 'InNetwork': 'InNetwork', 'Visibility': 'Visibility', 'Shape_Leng': 'Shape_Leng', 'NHDPlusID': 'NHDPlusID', 'VPUID': 'VPUID', 'Enabled': 'Enabled', });
lyr_StandingRockDistricts_1.set('fieldImages', {'AIANNHCE': 'TextEdit', 'TRSUBCE': 'TextEdit', 'TRSUBNS': 'TextEdit', 'GEOID': 'TextEdit', 'NAME': 'TextEdit', 'NAMELSAD': 'TextEdit', 'LSAD': 'TextEdit', 'CLASSFP': 'TextEdit', 'MTFCC': 'TextEdit', 'FUNCSTAT': 'TextEdit', 'ALAND': 'TextEdit', 'AWATER': 'TextEdit', 'INTPTLAT': 'TextEdit', 'INTPTLON': 'TextEdit', });
lyr_1011_HUC6_Clipped_2.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'TNMID': 'TextEdit', 'MetaSource': 'TextEdit', 'SourceData': 'TextEdit', 'SourceOrig': 'TextEdit', 'SourceFeat': 'TextEdit', 'LoadDate': 'DateTime', 'AreaSqKm': 'TextEdit', 'AreaAcres': 'TextEdit', 'GNIS_ID': 'Range', 'Name': 'TextEdit', 'States': 'TextEdit', 'HUC6': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_ProjectFP_3.set('fieldImages', {'id': 'TextEdit', 'name': 'TextEdit', });
lyr_LeafOnTheHillCreek_4.set('fieldImages', {'OBJECTID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'statecode': 'TextEdit', 'permanent_': 'TextEdit', 'fdate': 'TextEdit', 'resolution': 'TextEdit', 'gnis_id': 'TextEdit', 'gnis_name': 'TextEdit', 'lengthkm': 'TextEdit', 'reachcode': 'TextEdit', 'flowdir': 'TextEdit', 'wbarea_per': 'TextEdit', 'ftype': 'TextEdit', 'fcode': 'TextEdit', 'mainpath': 'TextEdit', 'innetwork': 'TextEdit', 'visibility': 'TextEdit', 'enabled': 'TextEdit', 'vpuid': 'TextEdit', 'nhdplusid': 'TextEdit', 'fmeasure': 'TextEdit', 'tmeasure': 'TextEdit', 'GlobalID': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_CannonballRivertributaries_5.set('fieldImages', {'OBJECTID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'statecode': 'TextEdit', 'permanent_': 'TextEdit', 'fdate': 'TextEdit', 'resolution': 'TextEdit', 'gnis_id': 'TextEdit', 'gnis_name': 'TextEdit', 'lengthkm': 'TextEdit', 'reachcode': 'TextEdit', 'flowdir': 'TextEdit', 'wbarea_per': 'TextEdit', 'ftype': 'TextEdit', 'fcode': 'TextEdit', 'mainpath': 'TextEdit', 'innetwork': 'TextEdit', 'visibility': 'TextEdit', 'enabled': 'TextEdit', 'vpuid': 'TextEdit', 'nhdplusid': 'TextEdit', 'fmeasure': 'TextEdit', 'tmeasure': 'TextEdit', 'GlobalID': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_CannonballRiversr_nhd_area_6.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': 'TextEdit', 'FDate': 'DateTime', 'Resolution': 'TextEdit', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'LengthKM': 'TextEdit', 'ReachCode': 'TextEdit', 'FlowDir': 'TextEdit', 'WBArea_Per': 'TextEdit', 'FType': 'TextEdit', 'FCode': 'TextEdit', 'MainPath': 'TextEdit', 'InNetwork': 'TextEdit', 'Visibility': 'TextEdit', 'Shape_Leng': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', 'Enabled': 'TextEdit', 'fid_2': 'TextEdit', 'OBJECTID_2': 'TextEdit', 'Permanen_1': 'TextEdit', 'FDate_2': 'DateTime', 'Resoluti_1': 'TextEdit', 'GNIS_ID_2': 'TextEdit', 'GNIS_Name_': 'TextEdit', 'AreaSqKm': 'TextEdit', 'Elevation': 'TextEdit', 'FType_2': 'TextEdit', 'FCode_2': 'TextEdit', 'Visibili_1': 'TextEdit', 'Shape_Le_1': 'TextEdit', 'Shape_Area': 'TextEdit', 'NHDPlusID_': 'TextEdit', 'VPUID_2': 'TextEdit', });
lyr_CannonballRiversr_nhd_flowline_7.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': 'TextEdit', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'LengthKM': 'TextEdit', 'ReachCode': 'TextEdit', 'FlowDir': 'Range', 'WBArea_Per': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'MainPath': 'Range', 'InNetwork': 'Range', 'Visibility': 'TextEdit', 'Shape_Leng': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', 'Enabled': 'Range', });
lyr_GrandRivertributaries_8.set('fieldImages', {'OBJECTID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'statecode': 'TextEdit', 'permanent_': 'TextEdit', 'fdate': 'TextEdit', 'resolution': 'TextEdit', 'gnis_id': 'TextEdit', 'gnis_name': 'TextEdit', 'lengthkm': 'TextEdit', 'reachcode': 'TextEdit', 'flowdir': 'TextEdit', 'wbarea_per': 'TextEdit', 'ftype': 'TextEdit', 'fcode': 'TextEdit', 'mainpath': 'TextEdit', 'innetwork': 'TextEdit', 'visibility': 'TextEdit', 'enabled': 'TextEdit', 'vpuid': 'TextEdit', 'nhdplusid': 'TextEdit', 'fmeasure': 'TextEdit', 'tmeasure': 'TextEdit', 'GlobalID': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_GrandRiversr_nhd_area_9.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': 'TextEdit', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'AreaSqKm': 'TextEdit', 'Elevation': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'Visibility': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', });
lyr_GrandRiversr_nhd_flowline_10.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': 'TextEdit', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'LengthKM': 'TextEdit', 'ReachCode': 'TextEdit', 'FlowDir': 'Range', 'WBArea_Per': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'MainPath': 'Range', 'InNetwork': 'Range', 'Visibility': 'TextEdit', 'Shape_Leng': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', 'Enabled': 'Range', });
lyr_OakCreek_11.set('fieldImages', {'OBJECTID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'statecode': 'TextEdit', 'permanent_': 'TextEdit', 'fdate': 'TextEdit', 'resolution': 'TextEdit', 'gnis_id': 'TextEdit', 'gnis_name': 'TextEdit', 'lengthkm': 'TextEdit', 'reachcode': 'TextEdit', 'flowdir': 'TextEdit', 'wbarea_per': 'TextEdit', 'ftype': 'TextEdit', 'fcode': 'TextEdit', 'mainpath': 'TextEdit', 'innetwork': 'TextEdit', 'visibility': 'TextEdit', 'enabled': 'TextEdit', 'vpuid': 'TextEdit', 'nhdplusid': 'TextEdit', 'fmeasure': 'TextEdit', 'tmeasure': 'TextEdit', 'GlobalID': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_MissouriRivertributariesmerge_12.set('fieldImages', {'OBJECTID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'statecode': 'TextEdit', 'permanent_': 'TextEdit', 'fdate': 'TextEdit', 'resolution': 'TextEdit', 'gnis_id': 'TextEdit', 'gnis_name': 'TextEdit', 'lengthkm': 'TextEdit', 'reachcode': 'TextEdit', 'flowdir': 'TextEdit', 'wbarea_per': 'TextEdit', 'ftype': 'TextEdit', 'fcode': 'TextEdit', 'mainpath': 'TextEdit', 'innetwork': 'TextEdit', 'visibility': 'TextEdit', 'enabled': 'TextEdit', 'vpuid': 'TextEdit', 'nhdplusid': 'TextEdit', 'fmeasure': 'TextEdit', 'tmeasure': 'TextEdit', 'GlobalID': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_MissouriRiversr_nhd_wb_13.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': '', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'AreaSqKm': 'TextEdit', 'Elevation': 'TextEdit', 'ReachCode': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'Visibility': '', 'Shape_Leng': '', 'Shape_Area': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', });
lyr_MissouriRiversr_nhd_area_14.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': '', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'AreaSqKm': 'TextEdit', 'Elevation': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'Visibility': '', 'Shape_Leng': '', 'Shape_Area': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', });
lyr_MissouriRiversr_nhd_flowline_15.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'Permanent_': 'TextEdit', 'FDate': 'DateTime', 'Resolution': 'Range', 'GNIS_ID': 'TextEdit', 'GNIS_Name': 'TextEdit', 'LengthKM': 'TextEdit', 'ReachCode': 'TextEdit', 'FlowDir': 'Range', 'WBArea_Per': 'TextEdit', 'FType': 'Range', 'FCode': 'Range', 'MainPath': 'Range', 'InNetwork': 'Range', 'Visibility': 'TextEdit', 'Shape_Leng': 'TextEdit', 'NHDPlusID': 'TextEdit', 'VPUID': 'TextEdit', 'Enabled': 'Range', });
lyr_StandingRockDistricts_1.set('fieldLabels', {'AIANNHCE': 'inline label - always visible', 'TRSUBCE': 'inline label - always visible', 'TRSUBNS': 'inline label - always visible', 'GEOID': 'inline label - always visible', 'NAME': 'inline label - always visible', 'NAMELSAD': 'inline label - always visible', 'LSAD': 'inline label - always visible', 'CLASSFP': 'inline label - always visible', 'MTFCC': 'inline label - always visible', 'FUNCSTAT': 'inline label - always visible', 'ALAND': 'inline label - always visible', 'AWATER': 'inline label - always visible', 'INTPTLAT': 'inline label - always visible', 'INTPTLON': 'inline label - always visible', });
lyr_1011_HUC6_Clipped_2.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'TNMID': 'inline label - always visible', 'MetaSource': 'inline label - always visible', 'SourceData': 'inline label - always visible', 'SourceOrig': 'inline label - always visible', 'SourceFeat': 'inline label - always visible', 'LoadDate': 'inline label - always visible', 'AreaSqKm': 'inline label - always visible', 'AreaAcres': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'Name': 'inline label - always visible', 'States': 'inline label - always visible', 'HUC6': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'Shape_Area': 'inline label - always visible', });
lyr_ProjectFP_3.set('fieldLabels', {'id': 'inline label - always visible', 'name': 'inline label - always visible', });
lyr_LeafOnTheHillCreek_4.set('fieldLabels', {'OBJECTID': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'statecode': 'inline label - always visible', 'permanent_': 'inline label - always visible', 'fdate': 'inline label - always visible', 'resolution': 'inline label - always visible', 'gnis_id': 'inline label - always visible', 'gnis_name': 'inline label - always visible', 'lengthkm': 'inline label - always visible', 'reachcode': 'inline label - always visible', 'flowdir': 'inline label - always visible', 'wbarea_per': 'inline label - always visible', 'ftype': 'inline label - always visible', 'fcode': 'inline label - always visible', 'mainpath': 'inline label - always visible', 'innetwork': 'inline label - always visible', 'visibility': 'inline label - always visible', 'enabled': 'inline label - always visible', 'vpuid': 'inline label - always visible', 'nhdplusid': 'inline label - always visible', 'fmeasure': 'inline label - always visible', 'tmeasure': 'inline label - always visible', 'GlobalID': 'inline label - always visible', 'layer': 'inline label - always visible', 'path': 'inline label - always visible', });
lyr_CannonballRivertributaries_5.set('fieldLabels', {'OBJECTID': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'statecode': 'inline label - always visible', 'permanent_': 'inline label - always visible', 'fdate': 'inline label - always visible', 'resolution': 'inline label - always visible', 'gnis_id': 'inline label - always visible', 'gnis_name': 'inline label - always visible', 'lengthkm': 'inline label - always visible', 'reachcode': 'inline label - always visible', 'flowdir': 'inline label - always visible', 'wbarea_per': 'inline label - always visible', 'ftype': 'inline label - always visible', 'fcode': 'inline label - always visible', 'mainpath': 'inline label - always visible', 'innetwork': 'inline label - always visible', 'visibility': 'inline label - always visible', 'enabled': 'inline label - always visible', 'vpuid': 'inline label - always visible', 'nhdplusid': 'inline label - always visible', 'fmeasure': 'inline label - always visible', 'tmeasure': 'inline label - always visible', 'GlobalID': 'inline label - always visible', 'layer': 'inline label - always visible', 'path': 'inline label - always visible', });
lyr_CannonballRiversr_nhd_area_6.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'LengthKM': 'inline label - always visible', 'ReachCode': 'inline label - always visible', 'FlowDir': 'inline label - always visible', 'WBArea_Per': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'MainPath': 'inline label - always visible', 'InNetwork': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', 'Enabled': 'inline label - always visible', 'fid_2': 'inline label - always visible', 'OBJECTID_2': 'inline label - always visible', 'Permanen_1': 'inline label - always visible', 'FDate_2': 'inline label - always visible', 'Resoluti_1': 'inline label - always visible', 'GNIS_ID_2': 'inline label - always visible', 'GNIS_Name_': 'inline label - always visible', 'AreaSqKm': 'inline label - always visible', 'Elevation': 'inline label - always visible', 'FType_2': 'inline label - always visible', 'FCode_2': 'inline label - always visible', 'Visibili_1': 'inline label - always visible', 'Shape_Le_1': 'inline label - always visible', 'Shape_Area': 'inline label - always visible', 'NHDPlusID_': 'inline label - always visible', 'VPUID_2': 'inline label - always visible', });
lyr_CannonballRiversr_nhd_flowline_7.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'LengthKM': 'inline label - always visible', 'ReachCode': 'inline label - always visible', 'FlowDir': 'inline label - always visible', 'WBArea_Per': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'MainPath': 'inline label - always visible', 'InNetwork': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', 'Enabled': 'inline label - always visible', });
lyr_GrandRivertributaries_8.set('fieldLabels', {'OBJECTID': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'statecode': 'inline label - always visible', 'permanent_': 'inline label - always visible', 'fdate': 'inline label - always visible', 'resolution': 'inline label - always visible', 'gnis_id': 'inline label - always visible', 'gnis_name': 'inline label - always visible', 'lengthkm': 'inline label - always visible', 'reachcode': 'inline label - always visible', 'flowdir': 'inline label - always visible', 'wbarea_per': 'inline label - always visible', 'ftype': 'inline label - always visible', 'fcode': 'inline label - always visible', 'mainpath': 'inline label - always visible', 'innetwork': 'inline label - always visible', 'visibility': 'inline label - always visible', 'enabled': 'inline label - always visible', 'vpuid': 'inline label - always visible', 'nhdplusid': 'inline label - always visible', 'fmeasure': 'inline label - always visible', 'tmeasure': 'inline label - always visible', 'GlobalID': 'inline label - always visible', 'layer': 'inline label - always visible', 'path': 'inline label - always visible', });
lyr_GrandRiversr_nhd_area_9.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'AreaSqKm': 'inline label - always visible', 'Elevation': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'Shape_Area': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', });
lyr_GrandRiversr_nhd_flowline_10.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'LengthKM': 'inline label - always visible', 'ReachCode': 'inline label - always visible', 'FlowDir': 'inline label - always visible', 'WBArea_Per': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'MainPath': 'inline label - always visible', 'InNetwork': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', 'Enabled': 'inline label - always visible', });
lyr_OakCreek_11.set('fieldLabels', {'OBJECTID': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'statecode': 'inline label - always visible', 'permanent_': 'inline label - always visible', 'fdate': 'inline label - always visible', 'resolution': 'inline label - always visible', 'gnis_id': 'inline label - always visible', 'gnis_name': 'inline label - always visible', 'lengthkm': 'inline label - always visible', 'reachcode': 'inline label - always visible', 'flowdir': 'inline label - always visible', 'wbarea_per': 'inline label - always visible', 'ftype': 'inline label - always visible', 'fcode': 'inline label - always visible', 'mainpath': 'inline label - always visible', 'innetwork': 'inline label - always visible', 'visibility': 'inline label - always visible', 'enabled': 'inline label - always visible', 'vpuid': 'inline label - always visible', 'nhdplusid': 'inline label - always visible', 'fmeasure': 'inline label - always visible', 'tmeasure': 'inline label - always visible', 'GlobalID': 'inline label - always visible', 'layer': 'inline label - always visible', 'path': 'inline label - always visible', });
lyr_MissouriRivertributariesmerge_12.set('fieldLabels', {'OBJECTID': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'statecode': 'inline label - always visible', 'permanent_': 'inline label - always visible', 'fdate': 'inline label - always visible', 'resolution': 'inline label - always visible', 'gnis_id': 'inline label - always visible', 'gnis_name': 'inline label - always visible', 'lengthkm': 'inline label - always visible', 'reachcode': 'inline label - always visible', 'flowdir': 'inline label - always visible', 'wbarea_per': 'inline label - always visible', 'ftype': 'inline label - always visible', 'fcode': 'inline label - always visible', 'mainpath': 'inline label - always visible', 'innetwork': 'inline label - always visible', 'visibility': 'inline label - always visible', 'enabled': 'inline label - always visible', 'vpuid': 'inline label - always visible', 'nhdplusid': 'inline label - always visible', 'fmeasure': 'inline label - always visible', 'tmeasure': 'inline label - always visible', 'GlobalID': 'inline label - always visible', 'layer': 'inline label - always visible', 'path': 'inline label - always visible', });
lyr_MissouriRiversr_nhd_wb_13.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'AreaSqKm': 'inline label - always visible', 'Elevation': 'inline label - always visible', 'ReachCode': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'Shape_Area': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', });
lyr_MissouriRiversr_nhd_area_14.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'AreaSqKm': 'inline label - always visible', 'Elevation': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'Shape_Area': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', });
lyr_MissouriRiversr_nhd_flowline_15.set('fieldLabels', {'fid': 'inline label - always visible', 'OBJECTID': 'inline label - always visible', 'Permanent_': 'inline label - always visible', 'FDate': 'inline label - always visible', 'Resolution': 'inline label - always visible', 'GNIS_ID': 'inline label - always visible', 'GNIS_Name': 'inline label - always visible', 'LengthKM': 'inline label - always visible', 'ReachCode': 'inline label - always visible', 'FlowDir': 'inline label - always visible', 'WBArea_Per': 'inline label - always visible', 'FType': 'inline label - always visible', 'FCode': 'inline label - always visible', 'MainPath': 'inline label - always visible', 'InNetwork': 'inline label - always visible', 'Visibility': 'inline label - always visible', 'Shape_Leng': 'inline label - always visible', 'NHDPlusID': 'inline label - always visible', 'VPUID': 'inline label - always visible', 'Enabled': 'inline label - always visible', });
lyr_MissouriRiversr_nhd_flowline_15.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});